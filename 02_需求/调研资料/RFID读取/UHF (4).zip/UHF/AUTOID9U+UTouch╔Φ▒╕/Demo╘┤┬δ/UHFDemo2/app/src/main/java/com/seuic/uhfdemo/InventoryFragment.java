package com.seuic.uhfdemo;


import android.graphics.Color;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.seuic.uhf.EPC;
import com.seuic.uhf.UHFService;
import com.seuic.uhfdemo.databinding.FragmentInventoryBinding;
import com.seuic.uhfdemo.databinding.FragmentSettingsBinding;
import com.seuic.uhfdemo.databinding.ItemEpcBinding;

import java.util.ArrayList;
import java.util.List;

public class InventoryFragment extends Fragment {

	public static final int MAX_LEN = 64;



	public static final int ItemSelectColor = 0x44000000;
	private static final String TAG = InventoryFragment.class.getSimpleName();

	private FragmentInventoryBinding mFragmentInventoryBinding;

	private UHFService mDevice;

	private InventoryRunable mInventoryRunable;
	public boolean mInventoryStart = false;
	private Thread mInventoryThread;

	private Button btn_once;
	private Button btn_continue;
	private Button btn_stop;

	private ListView lv_id;

	private List<EPC> mEPCList;
	private InventoryAdapter mAdapter;
	private InventoryViewModel mInventoryViewModel;
	private MutableLiveData<List<EPC>> mEPCListLiveData;
	private MutableLiveData<Integer> mSelectedIndex;
	HandlerClick handlerClick;

	View currentView;

	static int m_count = 0;

	private static InventoryFragment inventoryfragment;

	public static InventoryFragment getInstance() {
		if (inventoryfragment == null)
			inventoryfragment = new InventoryFragment();
		return inventoryfragment;
	}


	// sound
	private static SoundPool mSoundPool;
	private static int soundID;
	/*
	 * static { mSoundPool = new SoundPool(3, AudioManager.STREAM_MUSIC, 20);
	 * soundID = mSoundPool.load(getContext(),R.raw.scan, 1); }
	 */

	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mInventoryViewModel = new ViewModelProvider(requireActivity()).get(InventoryViewModel.class);
		mEPCListLiveData = mInventoryViewModel.getEPCListLiveData();
		mSelectedIndex = mInventoryViewModel.getSelectedIndex();

	}
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		mDevice = UHFService.getInstance();

		mFragmentInventoryBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_inventory, container, false);
		mFragmentInventoryBinding.setVm(mInventoryViewModel);
		handlerClick = new HandlerClick();
		mFragmentInventoryBinding.setHandler(handlerClick);

		currentView = mFragmentInventoryBinding.getRoot();
		initUI(currentView);

		mEPCList = new ArrayList<EPC>();
		if(mEPCListLiveData.getValue()!=null){
			mEPCList = mEPCListLiveData.getValue();
		}
		mAdapter = new InventoryAdapter(mEPCList);
		mInventoryRunable = new InventoryRunable();
		lv_id.setAdapter(mAdapter);

		lv_id.setOnItemClickListener(new MyItemClickListener());

		mEPCListLiveData.observe(getViewLifecycleOwner(), new Observer<List<EPC>>() {
			@Override
			public void onChanged(List<EPC> epcs) {
				mAdapter.setEPCList(epcs);
				mAdapter.notifyDataSetChanged();
			}
		});
		return currentView;
	}


	@Override
	public void onResume() {

		super.onResume();

		// handler.sendEmptyMessage(2);

	}

	// init UI
	private View initUI(View currentView) {

		lv_id = (ListView) currentView.findViewById(R.id.lv_id);

		btn_once = (Button) currentView.findViewById(R.id.bt_once);

		btn_continue = (Button) currentView.findViewById(R.id.bt_continue);

		btn_stop = (Button) currentView.findViewById(R.id.bt_stop);


		mSoundPool = new SoundPool(3, AudioManager.STREAM_MUSIC, 20);
		soundID = mSoundPool.load(currentView.getContext(), R.raw.scan, 1);

		return currentView;
	}

	// 条码list刷新
	private void refreshData() {

		if (mEPCList != null) {
			// Gets the number inside the list of all labels
			int count = 0;
			for (EPC item : mEPCList) {
				count += item.count;
			}
			if (count > m_count) {
				playSound();
			}
			mInventoryViewModel.EPC_total.set(mEPCList.size());
			m_count = count;
		}
	}

	// EPC list item listener
	private class MyItemClickListener implements OnItemClickListener {
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

			mSelectedIndex.setValue(position);
			mAdapter.notifyDataSetInvalidated();
			/*
			 * ListView listview = (ListView) parent; HashMap<String, Object>
			 * data = (HashMap<String, Object>)
			 * listview.getItemAtPosition(position); String epc =
			 * data.get("epc").toString(); Toast.makeText(getActivity(), epc,
			 * 0).show();
			 */
		}
	}

	private void clearList() {
		mSelectedIndex.setValue(-1);
		if (mEPCList != null) {
			mEPCList.clear();
			mEPCListLiveData.setValue(mEPCList);
			m_count = 0;
		}
	}

	public class HandlerClick{
		public void BtnOnce() {
			EPC epc = new EPC();
			if (mDevice.inventoryOnce(epc, 100)) {
				String id = epc.getId();
				System.out.println("" + id);
				if (id != null && !"".equals(id)) {
					playSound();
					boolean exist = false;
					for (EPC item : mEPCList) {
						if (item.equals(epc)) {
							item.count++;
							exist = true;
							break;
						}
					}
					if (!exist) {
						mEPCList.add(epc);
						mEPCListLiveData.setValue(mEPCList);
					}
					refreshData();
					mAdapter.notifyDataSetChanged();
				}
				System.out.println("OK!!!");
			}
			return;
		}

		public void BtnContinue() {
			clearList();
			if (mInventoryThread != null && mInventoryThread.isAlive()) {
				System.out.println("Thread not null");
				return;
			}

			if (mDevice.inventoryStart()) {
				System.out.println("RfidInventoryStart sucess.");

				mInventoryStart = true;
				mInventoryThread = new Thread(mInventoryRunable);
				mInventoryThread.start();

				btn_continue.setEnabled(false);
				btn_once.setEnabled(false);
				btn_stop.setEnabled(true);

			} else {
				System.out.println("RfidInventoryStart faild.");
			}
			return;
		}

		public void BtnStop() {
			mInventoryStart = false;

			if (mInventoryThread != null) {
				mInventoryThread.interrupt();
				mInventoryThread = null;
			}
			System.out.println("begin stop!!");
			if (mDevice.inventoryStop()) {
				System.out.println("end stop!!");
				btn_once.setEnabled(true);
				btn_continue.setEnabled(true);
				btn_stop.setEnabled(false);

			} else {
				System.out.println("RfidInventoryStop faild.");
			}
			return;
		}

		public void BtnRead() {
			int index = -1;
			if ((index=mSelectedIndex.getValue()) >= 0) {

				if (mInventoryViewModel.bank.get().isEmpty() ||mInventoryViewModel.address.get().isEmpty() || mInventoryViewModel.length.get().isEmpty()) {
					Toast.makeText(getActivity(), R.string.the_parameter_cannot_be_empty, Toast.LENGTH_SHORT).show();
					return;
				}
				int bank = Integer.parseInt(mInventoryViewModel.bank.get().toString());
				int address = Integer.parseInt(mInventoryViewModel.address.get().toString());
				int length = Integer.parseInt(mInventoryViewModel.length.get().toString());

				String str_password = mInventoryViewModel.password.get().toString().trim();

				String Epc = mEPCList.get(index).getId();

				byte[] btPassword = new byte[16];
				BaseUtil.getHexByteArray(str_password, btPassword, btPassword.length);
				byte[] buffer = new byte[MAX_LEN];
				if (length > MAX_LEN) {
					buffer = new byte[length];
				}

				if (!mDevice.readTagData(BaseUtil.getHexByteArray(Epc), btPassword, bank, address, length, buffer)) {

					Toast.makeText(getActivity(), R.string.readTagData_faild, Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(getActivity(), R.string.readTagData_sucess, Toast.LENGTH_SHORT).show();
					String data = BaseUtil.getHexString(buffer, length, " ");
					mInventoryViewModel.data.set(data);
				}

			} else {
				Toast.makeText(getActivity(), R.string.please_select_a_tag, Toast.LENGTH_SHORT).show();
			}

		}

		public void BtnWrite() {
			int index = -1;
			if ((index=mSelectedIndex.getValue()) >= 0) {
				if (mInventoryViewModel.bank.get().isEmpty() ||mInventoryViewModel.address.get().isEmpty() || mInventoryViewModel.length.get().isEmpty()) {
					Toast.makeText(getActivity(), R.string.the_parameter_cannot_be_empty, Toast.LENGTH_SHORT).show();
					return;
				}
				int bank = Integer.parseInt(mInventoryViewModel.bank.get().toString());
				int address = Integer.parseInt(mInventoryViewModel.address.get().toString());
				int length = Integer.parseInt(mInventoryViewModel.length.get().toString());

				String str_password = mInventoryViewModel.password.get().toString().trim();

				String Epc = mEPCList.get(index).getId();

				byte[] btPassword = new byte[16];
				BaseUtil.getHexByteArray(str_password, btPassword, btPassword.length);

				String str_data = mInventoryViewModel.data.get().toString().replace(" ", "");
				if (str_data.isEmpty()) {
					Toast.makeText(getActivity(), R.string.writeData_cannot_be_empty, Toast.LENGTH_SHORT).show();
					return;
				}
				byte[] buffer = new byte[MAX_LEN];
				if (length > MAX_LEN) {
					buffer = new byte[length];
				}
				BaseUtil.getHexByteArray(str_data, buffer, length);

				if (!mDevice.writeTagData(BaseUtil.getHexByteArray(Epc), btPassword, bank, address, length, buffer)) {

					Toast.makeText(getActivity(), R.string.writeTagData_faild, Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(getActivity(), R.string.writeTagData_sucess, Toast.LENGTH_SHORT).show();

				}
			} else {
				Toast.makeText(getActivity(), R.string.please_select_a_tag, Toast.LENGTH_SHORT).show();
			}
		}

		public void BtnClear() {
			mInventoryViewModel.data.set(null);
		}

	}

	private void playSound() {
		if (mSoundPool == null) {
			mSoundPool = new SoundPool(3, AudioManager.STREAM_MUSIC, 20);
			soundID = mSoundPool.load(currentView.getContext(), R.raw.scan, 1);// "/system/media/audio/notifications/Antimony.ogg"
		}
		mSoundPool.play(soundID, 1, 1, 0, 0, 1);
	}

	public class InventoryAdapter extends BaseAdapter {
		private List<EPC> mEPCList;

		public InventoryAdapter(List<EPC> list) {
			mEPCList = list;
		}

		public void setEPCList(List<EPC> epcs){
			mEPCList = epcs;
		}

		@Override
		public int getCount() {

			// return 0;
			if (mEPCList != null) {
				return mEPCList.size();
			}
			return 0;
		}

		@Override
		public Object getItem(int position) {

			// return null;
			return mEPCList.get(position);
		}

		@Override
		public long getItemId(int position) {

			// return 0;
			return position;
		}

		@Override
		public void notifyDataSetChanged() {
			super.notifyDataSetChanged();
			mSelectedIndex.setValue(-1);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ItemEpcBinding epcBinding;
			if(convertView == null){
				epcBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.item_epc, parent ,false);
				convertView = epcBinding.getRoot();
			}else{
				epcBinding = DataBindingUtil.getBinding(convertView);
			}

			EPC epc = mEPCList.get(position);
			epcBinding.setEpc(epc);
			if (position == mSelectedIndex.getValue()) {
				convertView.setBackgroundColor(ItemSelectColor);
			}else{
				convertView.setBackgroundColor(Color.WHITE);
			}
			return convertView;
		}

	}


	private class InventoryRunable implements Runnable {
		@Override
		public void run() {

			while (mInventoryStart) {
				mEPCList = mDevice.getTagIDs();
				mEPCListLiveData.postValue(mEPCList);
				refreshData();
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}

		}
	}
}
