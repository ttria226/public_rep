package com.seuic.uhfdemo;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import com.seuic.uhf.UHFService;
import com.seuic.uhfdemo.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
	private RadioButton rb_inventory;
	private RadioButton rb_settings;
	private UHFService mDevice;
	private ActivityMainBinding binding;

	private FragmentManager fm;
	private FragmentTransaction ft;

	private InventoryFragment m_inventory;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ActionBar actionBar = getSupportActionBar();
		actionBar.setDisplayShowHomeEnabled(true);
		actionBar.setLogo(R.drawable.ic_launcher);
		actionBar.setDisplayUseLogoEnabled(true);
		mDevice = UHFService.getInstance();
		binding = DataBindingUtil.setContentView(this,R.layout.activity_main);
		binding.setListener(new Listener());

		// new object

		// open UHF
		//boolean ret = mDevice.open();
		//if (!ret) {
		//	Toast.makeText(this, R.string.open_failed, 1).show();
		//}

		rb_inventory = (RadioButton) findViewById(R.id.rb_inventory);
		rb_settings = (RadioButton) findViewById(R.id.rb_settings);

		fm = getSupportFragmentManager();
		ft = fm.beginTransaction();
		m_inventory = InventoryFragment.getInstance();
		ft.replace(R.id.frl_content, m_inventory);
		rb_inventory.setEnabled(false);

		ft.commit();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	protected void onResume() {
		super.onResume();
		// new object
		//mDevice = UHFService.getInstance();
		// open UHF
		boolean ret = mDevice.open();
		if (!ret) {
			Toast.makeText(this, R.string.open_failed, Toast.LENGTH_LONG).show();
		}

	}

	@Override
	protected void onPause() {
		super.onPause();
		// close UHF
		mDevice.close();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_exit) {
			mDevice.close();
			// Toast.makeText(this, "exit", 0).show();
			System.exit(0);
			return true;
		}
		if (id == R.id.action_hide) {
			// Toast.makeText(this, "hide", 0).show();
			this.finish();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public class Listener{
		public void onClick(View v){
			ft = fm.beginTransaction();
			switch (v.getId()) {
				case R.id.rb_inventory:
					ft.replace(R.id.frl_content, InventoryFragment.getInstance());
					rb_inventory.setEnabled(false);
					rb_settings.setEnabled(true);
					break;

				case R.id.rb_settings:
					if (!m_inventory.mInventoryStart) {
						ft.replace(R.id.frl_content, SettingsFragment.getInstance());
						rb_settings.setEnabled(false);
					}
					rb_inventory.setEnabled(true);

					break;

				default:
					break;
			}
			ft.commit();
		}
	}

}
