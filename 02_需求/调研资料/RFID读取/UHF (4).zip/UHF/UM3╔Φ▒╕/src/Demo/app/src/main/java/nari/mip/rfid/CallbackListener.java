package nari.mip.rfid;

public interface CallbackListener {
    public void callback(boolean success, String msg);
}
