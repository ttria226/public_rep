package nari.mip.rfid;
import java.util.List;

public interface QueryCallbackListener {
    void callback(boolean success, String msg, List<String> results);
}
