package com.seuic.UM3;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import nari.mip.rfid.CallbackListener;
import nari.mip.rfid.QueryCallbackListener;
import nari.mip.rfid.RfidImpl;
import nari.mip.rfid.RfidTag;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.tvInfo)
    TextView tvInfo;
    @BindView(R.id.btnInit)
    Button btnInit;
    @BindView(R.id.btnOpen)
    Button btnOpen;
    @BindView(R.id.btnSearchTag)
    Button btnSearchTag;
    @BindView(R.id.btnStopSearchTag)
    Button btnStopSearchTag;
    @BindView(R.id.btnRead)
    Button btnRead;
    @BindView(R.id.btnWrite)
    Button btnWrite;
    @BindView(R.id.btnSetAccessPwd)
    Button btnSetAccessPwd;
    @BindView(R.id.btnDeleteAccessPwd)
    Button btnDeleteAccessPwd;
    @BindView(R.id.btnSetKillPwd)
    Button btnSetKillPwd;
    @BindView(R.id.btnDeleteKillPwd)
    Button btnDeleteKillPwd;
    @BindView(R.id.btnErase)
    Button btnErase;
    @BindView(R.id.btnLockTag)
    Button btnLockTag;
    @BindView(R.id.btnKillTag)
    Button btnKillTag;
    @BindView(R.id.btnClose)
    Button btnClose;

    private RfidImpl rfid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        rfid=new RfidImpl();
    }

    @OnClick({R.id.btnInit, R.id.btnOpen, R.id.btnSearchTag, R.id.btnStopSearchTag,
            R.id.btnRead, R.id.btnWrite, R.id.btnSetAccessPwd, R.id.btnDeleteAccessPwd,
            R.id.btnSetKillPwd, R.id.btnDeleteKillPwd, R.id.btnErase, R.id.btnLockTag,
            R.id.btnKillTag, R.id.btnClose})
    public void onViewClicked(View view) {
        RfidTag tag=new RfidTag();
        switch (view.getId()) {
            case R.id.btnInit:
                rfid.init(MainActivity.this, "", new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvInfo.setText("init:"+msg);
                            }
                        });
                    }
                });
                break;
            case R.id.btnOpen:
                rfid.open(new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("open:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnSearchTag:
                rfid.searchTag(queryCallbackListener);
                break;
            case R.id.btnStopSearchTag:
                rfid.stopSearchTag(new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("stopSearchTag:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnRead:
                tag.setId("6400911151342508661905301000010100739951400000020501");
                tag.setMemoryRegion(3);
                tag.setOffset(0);
                tag.setLength(16);
                tag.setAccessPwd("00000000");
                rfid.read(tag, new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("read:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnWrite:
                RfidTag tag1=new RfidTag();
                tag1.setId("6400911151342508661905301000010100739951400000020501");
                tag1.setMemoryRegion(3);
                tag1.setOffset(0);
                tag1.setLength(2);
                tag1.setAccessPwd("00000000");
                rfid.write(tag1, "3132", new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("write:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnSetAccessPwd:
                tag.setId("6400911151342508661905301000010100739951400000020501");
                tag.setAccessPwd("00000000");
                rfid.setAccessPwd(tag, "11111111", new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("setAccessPwd:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnDeleteAccessPwd:
                tag.setId("6400911151342508661905301000010100739951400000020501");
                tag.setAccessPwd("11111111");
                rfid.deleteAccessPwd(tag, new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("deleteAccessPwd:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnSetKillPwd:
                tag.setId("6400911151342508661905301000010100739951400000020501");
                tag.setAccessPwd("00000000");
                rfid.setKillPwd(tag, new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("setKillPwd:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnDeleteKillPwd:
                tag.setId("6400911151342508661905301000010100739951400000020501");
                tag.setAccessPwd("00000000");
                rfid.deleteKillPwd(tag, new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("deleteKillPwd:"+msg);
                        });
                    }
                });
                break;
            case R.id.btnErase:
                break;
            case R.id.btnLockTag:
                break;
            case R.id.btnKillTag:
                break;
            case R.id.btnClose:
                rfid.close(new CallbackListener() {
                    @Override
                    public void callback(boolean success, String msg) {
                        runOnUiThread(()->{
                            tvInfo.setText("close:"+msg);
                        });
                    }
                });
                break;
        }
    }

    QueryCallbackListener queryCallbackListener=new QueryCallbackListener() {
        @Override
        public void callback(boolean success, String msg, List<String> results) {
            runOnUiThread(()->{
                tvInfo.setText(msg+"==========寻卡数量:"+results.size());
            });
        }
    };

}
