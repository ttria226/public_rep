package nari.mip.rfid;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.seuic.sleduhf.DecodeInfo;
import com.seuic.sleduhf.EPC;
import com.seuic.sleduhf.UhfCallback;
import com.seuic.sleduhf.UhfDevice;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class RfidImpl {

    private String btMc;
    private UhfDevice uhfDevice;
    private CallbackListener callbackListener;
    private QueryCallbackListener queryCallbackListener;



    UhfCallback uhfCallback= new UhfCallback() {
        @Override
        public void onGetBtInfo(BluetoothDevice bluetoothDevice) {

        }

        @Override
        public void onGetConnectStatus(int i) {
            Log.i(TAG, "onGetConnectStatus: i:"+i);
            switch (i)
            {
                case 0:
                    Log.i(TAG, "onGetConnectStatus: 连接成功");
                     callbackListener.callback(true,"设备连接成功！");
                    break;
                case -1:
                    Log.i(TAG, "onGetConnectStatus: 断开连接");
                    callbackListener.callback(false,"断开连接！");
                    break;
                case -2:
                    Log.i(TAG, "onGetConnectStatus: 连接超时");
                    callbackListener.callback(false,"连接超时！");
                    break;
            }
        }

        @Override
        public void onGetTagsId(List<EPC> list) {
            if (queryCallbackListener!=null) {
                List<String> datas=new ArrayList<>();
                for (EPC epc:list) {
                    datas.add(epc.getId());
                }
                queryCallbackListener.callback(true, "寻卡标签数据！", datas);
            };
        }
        @Override
        public void onGetScanKeyMode(int i) {
        }

        @Override
        public void onDecodeComplete(DecodeInfo decodeInfo) {
        }
    };
    private static final String TAG = "RfidImpl";
    public void init(Context context,String soLibPath, CallbackListener listener){
        if (uhfDevice==null)
            uhfDevice=UhfDevice.getInstance(context);
        uhfDevice.registerUhfCallback(uhfCallback);
        callbackListener=listener;
        BluetoothAdapter btAdapter=BluetoothAdapter.getDefaultAdapter();
        if (!btAdapter.isEnabled())
            listener.callback(false,"蓝牙不可用！");
        Set<BluetoothDevice> devices=btAdapter.getBondedDevices();
        if (devices.size()>0){
            for (BluetoothDevice dev:devices) {
                Log.i(TAG, "init: bluetooth address:"+dev.getAddress());
                if (dev.getAddress().startsWith("00:15")){
                    btMc=dev.getAddress();
                    uhfDevice.connect(btMc,5000);
                    break;
                }
            }
        }else {
            listener.callback(false,"未找到已连接配对设备！");
        }
    }

    public void open(CallbackListener listener){
        try{
            String mc="";
            for (int i = 0; i <3; i++) {
                Thread.sleep(800);
                mc=uhfDevice.getSledAddress();
                Log.i(TAG, "open: mc:"+mc);
                if (!TextUtils.isEmpty(mc))
                    break;
            }
            if (!TextUtils.isEmpty(mc)) {
                btMc=mc;
                listener.callback(true,"设备打开成功！");
            }
            else
                listener.callback(false, "设备打开失败！");
        }catch (Exception ex){
            listener.callback(false, "设备打开失败！");
        }
    }

    public void close(CallbackListener listener){
        try {
            if (uhfDevice != null) {
                uhfDevice.unregisterUhfCallback(uhfCallback);
                uhfDevice.disconnect();
            }
            listener.callback(true, "设备关闭成功！");
        }catch (Exception ex){
            listener.callback(true,"设备关闭失败！");
        }
    }

    public void searchTag(QueryCallbackListener listener){
        boolean flg=uhfDevice.inventoryStart();
        queryCallbackListener=listener;
    }

    public void stopSearchTag(CallbackListener listener){
        boolean flg=uhfDevice.inventoryStop();
        if (flg) {
            queryCallbackListener=null;
            listener.callback(true, "停止寻卡操作成功！");
        }
        else
            listener.callback(true, "停止寻卡操作失败！");
    }

    public void setAccessPwd(RfidTag tag, String newPwd, CallbackListener listener){
        byte[] epc=BaseUtil.getHexByteArray(tag.getId());
        byte[] btPassword = new byte[16];
        BaseUtil.getHexByteArray(tag.getAccessPwd(), btPassword, btPassword.length);
        int bank=0;
        int offset=4;
        int len=4;
        boolean flg=uhfDevice.writeTagData(epc,btPassword,bank,offset,len,BaseUtil.getHexByteArray(newPwd.trim()));
        if (flg) {
            listener.callback(true, "修改访问密码成功！");
        }
        else
            listener.callback(false,"修改访问密码失败！");
    }

    public void deleteAccessPwd(RfidTag tag, CallbackListener listener){
        byte[] epc=BaseUtil.getHexByteArray(tag.getId());
        byte[] btPassword = new byte[16];
        BaseUtil.getHexByteArray(tag.getAccessPwd(), btPassword, btPassword.length);
        int bank=0;
        int offset=4;
        int len=4;
        boolean flg=uhfDevice.writeTagData(epc,btPassword,bank,offset,len,BaseUtil.getHexByteArray("00000000"));
        if (flg)
            listener.callback(true,"删除访问密码成功！");
        else
            listener.callback(false,"删除访问密码失败！");
    }

    public void setKillPwd(RfidTag tag, CallbackListener listener){
        byte[] epc=BaseUtil.getHexByteArray(tag.getId());
        byte[] btPassword = new byte[16];
        BaseUtil.getHexByteArray(tag.getAccessPwd(), btPassword, btPassword.length);
        int bank=0;
        int offset=0;
        int len=4;
        boolean flg =false;
        try {
            flg = uhfDevice.writeTagData(epc, btPassword, bank, offset, len, BaseUtil.getHexByteArray(tag.getKillPwd().trim()));
        }catch (Exception e){e.printStackTrace();}
        if (flg)
            listener.callback(true,"修改销毁标签密码成功！");
        else
            listener.callback(false,"修改销毁标签密码失败！");
    }

    public void deleteKillPwd(RfidTag tag, CallbackListener listener){
        byte[] epc=BaseUtil.getHexByteArray(tag.getId());
        byte[] btPassword = new byte[16];
        BaseUtil.getHexByteArray(tag.getAccessPwd(), btPassword, btPassword.length);
        int bank=0;
        int offset=0;
        int len=4;
        boolean flg = false;
        try {
            flg = uhfDevice.writeTagData(epc, btPassword, bank, offset, len, BaseUtil.getHexByteArray(tag.getKillPwd().trim()));
        }catch (Exception e){e.printStackTrace();}
        if (flg)
            listener.callback(true,"删除销毁标签密码成功！");
        else
            listener.callback(false,"删除销毁标签密码失败！");
    }

    public void read(RfidTag tag, CallbackListener listener){
        if (tag.getOffset()<0||tag.getLength()>getMaxLength(tag.getMemoryRegion())||
                (tag.getOffset()+tag.getLength())>getMaxLength(tag.getMemoryRegion())){
            listener.callback(false, "写入数据溢出错误！");
            return;
        }
        byte [] data=new byte[64];
        boolean flg=uhfDevice.readTagData(BaseUtil.getHexByteArray(tag.getId()),BaseUtil.getHexByteArray(tag.getAccessPwd()),
                tag.getMemoryRegion(),tag.getOffset(),tag.getLength(),data);
        if (flg)
            listener.callback(true,BaseUtil.getHexString(data,data.length));
        else
            listener.callback(false,"读取数据失败！");
    }

    public void write(RfidTag tag, String content, CallbackListener listener){
        if (tag.getOffset()<0||tag.getLength()>getMaxLength(tag.getMemoryRegion())||
                (tag.getOffset()+tag.getLength())>getMaxLength(tag.getMemoryRegion())) {
            listener.callback(false, "写入数据溢出错误！");
            return;
        }
        boolean flg=uhfDevice.writeTagData(BaseUtil.getHexByteArray(tag.getId()),BaseUtil.getHexByteArray(tag.getAccessPwd()),
                tag.getMemoryRegion(),tag.getOffset(),tag.getLength(),content.getBytes());
        if (flg)
            listener.callback(true,"写入数据成功！");
        else
            listener.callback(false,"写入数据失败！");
    }

    public void erase(RfidTag tag, CallbackListener listener){
        if (tag.getOffset()<0||tag.getLength()>getMaxLength(tag.getMemoryRegion())||
                (tag.getOffset()+tag.getLength())>getMaxLength(tag.getMemoryRegion())){
            listener.callback(false, "写入数据溢出错误！");
            return;
        }
        byte [] data=new byte[64];
        boolean flg=uhfDevice.writeTagData(BaseUtil.getHexByteArray(tag.getId()),BaseUtil.getHexByteArray(tag.getAccessPwd()),
                tag.getMemoryRegion(),tag.getOffset(),tag.getLength(),data);
        if (flg)
            listener.callback(true,"写入数据成功！");
        else
            listener.callback(false,"写入数据失败！");
    }

    public void lockTag (RfidTag tag, int lockCode, CallbackListener listener){
        int lg;
        if (lockCode==0||lockCode==2){//可写操作，也就是解锁
            switch (tag.getMemoryRegion()){
                case 0:
                    lg=0;
                    break;
                case 1:
                    lg=1;
                    break;
                case 2:
                    lg=2;
                    break;
                case 3:
                    lg=3;
                    break;
            }
        }else {//锁标签 操作
            switch (tag.getMemoryRegion()){
                case 0:
                    lg=10;
                    break;
                case 1:
                    lg=11;
                    break;
                case 2:
                    lg=12;
                    break;
                case 3:
                    lg=13;
                    break;
            }
        }
        boolean flg=uhfDevice.lockTag(BaseUtil.getHexByteArray(tag.getId()),
                BaseUtil.getHexByteArray(tag.getAccessPwd()),lockCode);
        if (flg)
            listener.callback(true,"锁定标签成功！");
        else
            listener.callback(false,"锁定标签失败！");
    }

    public void killTag (RfidTag tag, CallbackListener listener){
        boolean flg=uhfDevice.killTag(BaseUtil.getHexByteArray(tag.getId()),
                BaseUtil.getHexByteArray(tag.getAccessPwd()));
        if (flg)
            listener.callback(true,"销毁标签成功！");
        else
            listener.callback(false,"销毁标签失败！");
    }

    private int getMaxLength(int paramBank) {
        switch (paramBank) {
            case 1:
                return 10;
            case 0:
                return 4;
            case 2:
                return 6;
            case 3:
                break ;
        }return 32;

    }


}
